export const SUCCESS_CODE = 1000000
export const ERROR_CODE = 100010
export const TOKEN_ERROR_CODE = 100011
export const LOGIN_SUCCESS = '登录成功'
export const LOGIN_FIAL = '登录失败'
export const ERR_ACCOUNT_OR_ERR_PASSWORD = '账户名或密码错误'
export const REQUEST_SUCCESS = '请求成功'
export const REQUEST_FAIL = '请求失败'